# StonksManager

*Install dependencies*:
```
npm install --save-dev electron
npm install --save-dev python-shell
npm install --save-dev chart.js
pip install simplejson
```

*Run*:
```
npm start
```


# Chartjs

Extra branch for chartjs tests
